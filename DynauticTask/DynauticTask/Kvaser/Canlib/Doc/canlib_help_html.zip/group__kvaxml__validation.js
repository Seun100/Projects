var group__kvaxml__validation =
[
    [ "kvaXmlGetValidationError", "group__kvaxml__validation.html#gadac8df9ecbc2729d6e95ffcb003efbd3", null ],
    [ "kvaXmlGetValidationStatusCount", "group__kvaxml__validation.html#ga9d53368a802ab66813c3709c128f53fb", null ],
    [ "kvaXmlGetValidationText", "group__kvaxml__validation.html#gafbc7cf5eceb97fcb8c29b52f87e00aac", null ],
    [ "kvaXmlGetValidationWarning", "group__kvaxml__validation.html#ga7b5bd906ba11d31274345865f719a6b0", null ],
    [ "kvaXmlGetVersion", "group__kvaxml__validation.html#ga562657f33e1f2e0179839c453b2215c4", null ],
    [ "kvaXmlValidate", "group__kvaxml__validation.html#gabc8da31b49ae140171a66211efae7624", null ]
];