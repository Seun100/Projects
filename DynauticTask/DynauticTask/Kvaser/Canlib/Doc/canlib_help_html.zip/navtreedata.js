var NAVTREE =
[
  [ "Welcome to Kvaser CANlib SDK!", "index.html", [
    [ "Installation", "page_installing.html", "page_installing" ],
    [ "Tutorials", "page_tutorial.html", "page_tutorial" ],
    [ "CAN bus API (CANlib)", "page_canlib.html", "page_canlib" ],
    [ "LIN bus API (LINlib)", "page_linlib.html", [
      [ "Description", "page_linlib.html#section_user_guide_lin_lib_1", null ],
      [ "Using the LIN Bus", "page_linlib.html#section_user_guide_lin_intro", null ],
      [ "LIN Frame Identifiers", "page_linlib.html#section_user_guide_lin_frame_identifiers", null ],
      [ "Where to go from here", "page_linlib.html#section_user_guide_lin_where_to_go_from_here", null ]
    ] ],
    [ "J1587 API (J1587lib)", "page_j1587.html", [
      [ "Description", "page_j1587.html#section_user_guide_j1587_1", null ],
      [ "Where to go from here", "page_j1587.html#section_user_guide_j1587_where_to_go_from_here", null ]
    ] ],
    [ "Database API (kvaDbLib)", "page_kvadblib.html", "page_kvadblib" ],
    [ "Converter API (kvlclib)", "page_kvlclib.html", "page_kvlclib" ],
    [ "Memorator API (kvmlib)", "page_kvmlib.html", [
      [ "Description", "page_kvmlib.html#section_user_guide_kvmlib_1", null ],
      [ "Naming convention", "page_kvmlib.html#section_user_guide_kvmlib_2", null ],
      [ "Build an application", "page_kvmlib.html#section_user_guide_kvmlib_3", null ],
      [ "Where to go from here", "page_kvmlib.html#section_user_guide_kvmlib_where_to_go_from_here", null ]
    ] ],
    [ "Memorator XML API (kvaMemoLibXML)", "page_kvamemolibxml.html", [
      [ "Description", "page_kvamemolibxml.html#section_user_guide_kvamemolibxml_1", null ],
      [ "Build an application", "page_kvamemolibxml.html#section_user_guide_kvamemolibxml_2", null ],
      [ "Where to go from here", "page_kvamemolibxml.html#section_user_guide_kvamemolibxml_where_to_go_from_here", null ]
    ] ],
    [ "Remote Device API (kvrlib)", "page_kvrlib.html", "page_kvrlib" ],
    [ "Kvaser Support", "page_support.html", null ],
    [ "License and Copyright", "page_license_and_copyright.html", null ],
    [ "Compiling and Compatibility", "page_user_guide_build.html", "page_user_guide_build" ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"canlib_8h.html#abd2d501800e3dbfca7c687644210defa",
"example_2c_2kvdiag_2autobaud_8c-example.html",
"group___named_parameter_settings.html#ga7ef8f8128ca946e03a1bd3e17e9315fb",
"group__can__general.html#ga81d6e5302dee3d7b06fbcba0caed903d",
"group__kvadb__database.html#ga0da72bb21d2664d6443f7b3349ec9df5",
"group__kvdiag__diagnostics.html#ga61263295b3feaad95c257eef05a9579b",
"group__lin__status__codes.html#gga7a5ecfd2846ddd76cd49fb4edec7fc14acbbc856d7e5e7bddd0b2cb9c0638c268",
"kvlclib_8h.html#a9c7ced4f2adcbf319df93b79c0b86df3",
"kvrlib_8h.html#ab8ad7081141431d6cdd4152ecd84c0f2",
"struct_j1587_message_info.html#a278ac8112eb4d891fdffa2a26fb4de69"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';