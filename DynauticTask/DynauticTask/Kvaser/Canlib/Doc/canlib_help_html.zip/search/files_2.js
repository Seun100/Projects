var searchData=
[
  ['file_5fhandling_2etxt',['file_handling.txt',['../file__handling_8txt.html',1,'']]]
];
